<?php
include 'auth.php'; // Protects this script from unauthenticated access
include 'config.php';

// 1. Check if the 'id' parameter exists in the URL string
if (isset($_GET['id'])) {
    // 2. Sanitize the input by casting it to an Integer to prevent SQL Injection
    $id = (int)$_GET['id'];
    $page = (int)$_GET['page']; // Retrieve Page Number

    // 3. Construct the targeted DELETE query
    $sql = "DELETE FROM registration WHERE id = $id";

    // 4. Execute the query and redirect back with a success message
    if (mysqli_query($conn, $sql)) {
        header("Location: index.php?id=$id&page=$page&msg=deleted");
        exit();
    } else {
        // Handle database execution errors gracefully
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    // If someone tries to access delete.php directly without an ID, kick them back to the dashboard
    header("Location: index.php");
    exit();
}
?>