<?php
session_start();
include 'config.php';

// If already logged in, bypass login screen
if (isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true) {
    header("Location: home.php");
    exit();
}

if (isset($_POST['btn_login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['txt_user']);
    $password = $_POST['txt_pass'];

    if (empty($username) || empty($password)) {
        header("Location: loginex.php?err=empty");
        exit();
    }

    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        // Verify user input password against database-encrypted hash
        if (password_verify($password, $user['password'])) {
            $_SESSION['authenticated'] = true;
            $_SESSION['username'] = $user['username'];
            header("Location: home.php");
            exit();
        }
    }
    header("Location: loginex.php?err=invalid");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIS Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            background-color: #f3f4ff;
            font-family: 'Inter', sans-serif;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .signup-container {
            width: 900px;
            background: white;
            border-radius: 24px;
            display: flex;
            box-shadow: 0 30px 60px rgba(0,0,0,0.1);
            max-height: 95vh; 
        }

        .brand-section {
            background-image: url('SIS Ph.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;

            padding: 45px;
            color: white;
            width: 40%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border-radius: 24px 0 0 24px;
        }

        /* The Form Section: Using padding to control height */
        .form-section {
            width: 60%;
            padding: 40px 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .brand-logo { font-size: 1.8rem; margin-bottom: 20px; }
        .brand-text h2 { font-size: 1.8rem; font-weight: 700; }
        
        .form-label { font-size: 0.85rem; font-weight: 600; margin-bottom: 4px; }
        .form-control { padding: 10px; border-radius: 8px; border: 2px solid #eee; }
          input::placeholder {font-size: 12px;}
        
        .btn-get-started {
            background-color: #9142ff;
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 10px;
            margin-top: 10px;
        }

        /* smaller laptop screens without scrolling */
        @media (max-height: 700px) {
            .signup-container {
                transform: scale(0.9);
            }
        }
      
    </style>
</head>
<body>

    <div class="signup-container">
        <div class="brand-section">
 
        </div>

        <div class="form-section">
            <div class="mb-4">
                <span class="text-primary fs-4">✱</span>
                <h1 class="h3 fw-bold mt-2">Log into your account</h1>
                <p class="text-muted small mb-0">Log in to access the InterUni SIS Dashboard.</p>
            </div>

            <form method="POST">
                <?php if (isset($_GET['err'])): ?>
                <div class="alert alert-danger p-2 text-center" style="font-size: 0.9em;">
                    <?php echo ($_GET['err'] == 'empty') ? 'All fields are required.' : 'Invalid credentials.'; ?>
                </div>
            <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" class="form-control" name="txt_user" placeholder="Enter username here..." required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" name="txt_pass" placeholder="Enter password here..." required>
                </div>
                <button type="submit" name="btn_login" class="btn btn-primary btn-get-started w-100">Log in</button>
            </form>
        </div>
    </div>

</body>
</html>