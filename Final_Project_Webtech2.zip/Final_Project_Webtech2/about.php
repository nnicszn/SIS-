<?php
include 'auth.php'; // Protects this page
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - InterUni SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-purple: #9142ff;
            --primary-purple-hover: #7829e6;
            --light-purple: #f3e8ff;
            --text-dark: #2d213f;
        }
        body {
            background-color: #f8f9fa;
            color: var(--text-dark);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .nav-link-purple {
            color: #6c757d;
            font-weight: 500;
            transition: color 0.2s;
        }
        .nav-link-purple:hover, .nav-link-purple.active {
            color: var(--primary-purple) !important;
        }
        .dashboard-card {
            background: #ffffff;
            border-radius: 12px;
            border: none;
        }
        .developer-avatar {
            width: 100px;
            height: 100px;
            background-color: var(--light-purple);
            color: var(--primary-purple);
            font-size: 2.5rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            border: 2px solid rgba(145, 66, 255, 0.2);
        }
        .developer-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin: 0 auto 15px;
            border: 2px solid rgba(145, 66, 255, 0.2);
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: var(--light-purple);
        }
        .developer-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>
<body>

<div class="container my-5">
    <!-- Navbar Header Section -->
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 pb-3 border-bottom">
        <div class="mb-3 mb-md-0">
            <h2 class="fw-bold m-0" style="color: var(--text-dark);">InterUni SIS</h2>
            <small class="text-muted">Logged in as: <span class="badge bg-light text-dark border fw-semibold"><?php echo htmlspecialchars($_SESSION['username']); ?></span></small>
        </div>
        <nav>
            <ul class="nav gap-2">
                <li class="nav-item"><a class="nav-link nav-link-purple" href="home.php"><i class="bi bi-house-heart-fill"></i> Home</a></li>
                <li class="nav-item"><a class="nav-link nav-link-purple" href="index.php"><i class="bi bi-person-lines-fill"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link nav-link-purple active" href="about.php"><i class="bi bi-info-circle"></i> About</a></li>
                <li class="nav-item"><a class="nav-link text-danger" href="logout.php" onclick="return confirm('Log out from page?')"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
            </ul>
        </nav>
    </header>

    <!-- Main Content Grid -->
    <div class="row g-4">
        
        <!-- About System Card -->
        <div class="col-12">
            <div class="dashboard-card shadow-sm p-4 p-md-5">
                <div class="row align-items-center g-4">
                    <div class="col-md-8">
                        <span class="badge bg-light text-dark border mb-2 px-3 py-2 fw-semibold" style="color: var(--primary-purple) !important;">System Overview</span>
                        <h3 class="fw-bold mb-3">About InterUni SIS</h3>
                        <p class="text-muted lead">
                            The InterUni Student Information System (SIS) is developed to keep academic record of students from across multiple institutional universities in the Philippines.
                        </p>
                        <p class="text-muted">
                            Designed with modern responsive accessibility, this interface empowers administrators to securely manage registrations. The team used PHP and MySQL for backend operations, while Bootstrap 5 was utilized to create a clean frontend experience. The system features comprehensive CRUD functionalities, session-based authentication, and efficient data handling.
                        </p>
                    </div>
                    <div class="col-md-4 text-center d-none d-md-block">
                        <i class="bi bi-pc-display" style="font-size: 10rem; color: var(--primary-purple); opacity: 0.8;"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Header for Developers -->
        <div class="col-12 mt-5">
            <div class="text-center">
                <h3 class="fw-bold m-0">Meet the Development Team</h3>
                <p class="text-muted small">The minds behind InterUni SIS</p>
            </div>
        </div>

        <!-- Developer 1 -->
        <div class="col-md-4">
            <div class="dashboard-card shadow-sm p-4 text-center h-100 border-top border-4" style="border-top-color: var(--primary-purple) !important;">
                <div class="developer-avatar">
                    <img src="frances.jpg" alt="Developer Name 1">
                </div>
                <h5 class="fw-bold mb-1">Frances Ann Abarle</h5>
                <small class="text-muted d-block mb-3 fw-semibold">Project Leader & Full-Stack Developer</small>
                <p class="text-muted small">
                    Managed the front-end and back-end development, project timeline, and assigned specific tasks to team members to keep development on track.
                </p>
                <hr class="text-muted my-3">
                <div class="d-flex justify-content-center gap-3 text-muted">
                    <a href="https://wa.me/639773300604" target="_blank" class="text-decoration-none text-secondary" title="Contact-number"><i class="bi bi-whatsapp"></i></a>
                    <a href="https://www.facebook.com/frances.abarle" target="_blank" class="text-decoration-none text-secondary" title="Facebook"><i class="bi bi-facebook"></i></a>
                    <a href="mailto:abarlefrances@gmail.com" target="_blank" class="text-decoration-none text-secondary" title="Email"><i class="bi bi-envelope-fill fs-5"></i></a>
                </div>
            </div>
        </div>

        <!-- Developer 2 -->
        <div class="col-md-4">
            <div class="dashboard-card shadow-sm p-4 text-center h-100 border-top border-4" style="border-top-color: var(--primary-purple) !important;">
                <div class="developer-avatar">
                    <img src="dennis.jpg" alt="Developer Name 2">
                </div>
                <h5 class="fw-bold mb-1">Dennis Carreon</h5>
                <small class="text-muted d-block mb-3 fw-semibold">Documentation & Backend Developer</small>
                <p class="text-muted small">
                    Documented every phase of the system's development process and assisted with backend coding.
                </p>
                <hr class="text-muted my-3">
                <div class="d-flex justify-content-center gap-3 text-muted">
                    <a href="https://wa.me/639686468764" target="_blank" class="text-decoration-none text-secondary" title="Contact-number"><i class="bi bi-whatsapp"></i></a>
                    <a href="https://www.facebook.com/akichan07654" target="_blank" class="text-decoration-none text-secondary" title="Facebook"><i class="bi bi-facebook"></i></a>
                    <a href="mailto:denniscarreon@gmail.com" target="_blank" class="text-decoration-none text-secondary" title="Email"><i class="bi bi-envelope-fill fs-5"></i></a>
                </div>
            </div>
        </div>

        <!-- Developer 3 -->
        <div class="col-md-4">
            <div class="dashboard-card shadow-sm p-4 text-center h-100 border-top border-4" style="border-top-color: var(--primary-purple) !important;">
                <div class="developer-avatar">
                    <img src="danica.jpg" alt="Developer Name 3">
                </div>
                <h5 class="fw-bold mb-1">Danica Rodriguez</h5>
                <small class="text-muted d-block mb-3 fw-semibold">Editor & Frontend Developer</small>
                <p class="text-muted small">
                    Edited the final video presentation and helped design and code the user interface. 
                </p>
                <hr class="text-muted my-3">
                <div class="d-flex justify-content-center gap-3 text-muted">
                    <a href="https://wa.me/6396543789" target="_blank" class="text-decoration-none text-secondary" title="Contact-number"><i class="bi bi-whatsapp"></i></a>
                    <a href="https://www.facebook.com/devryennicszn" target="_blank" class="text-decoration-none text-secondary" title="Facebook"><i class="bi bi-facebook"></i></a>
                    <a href="mailto:danicarodriguez@gmail.com" target="_blank" class="text-decoration-none text-secondary" title="Email"><i class="bi bi-envelope-fill fs-5"></i></a>
                </div>
            </div>
        </div>

        <!-- Special Thanks Section -->
        <div class="col-12 mt-5">
            <div class="dashboard-card shadow-sm p-4 text-center" style="background: linear-gradient(135deg, rgba(145, 66, 255, 0.05) 0%, rgba(243, 232, 255, 0.5) 100%); border: 1px dashed rgba(145, 66, 255, 0.3);">
                <div class="mb-2">
                    <i class="bi bi-envelope-open-heart-fill text-danger fs-3"></i>
                </div>
                <h4 class="fw-bold mb-2">Special Thanks</h4>
                <p class="text-muted mx-auto mb-0" style="max-width: 700px;">
                    We would like to extend our gratitude to our professor, Sir Jerome, for his patience in teaching us how to develop a student information system and for providing starter codes that helped us get started with this project.
                    <br> To all the team members, thank your for your hard work and collaboration! Especially the part where you gathered all 50 student information <br> <br><div style="font-size: 8px;">Special thanks to Gemini! We truly couldn't have finished this project without its help.✨🙌🏻</div>
                </p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>