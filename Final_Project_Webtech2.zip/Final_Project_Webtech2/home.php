<?php
include 'auth.php'; // Protects this page
include 'config.php';

$total_students_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM registration");
$total_students = mysqli_fetch_assoc($total_students_res)['total'];

$total_univs_res = mysqli_query($conn, "SELECT COUNT(DISTINCT univ) as total FROM registration");
$total_univs = mysqli_fetch_assoc($total_univs_res)['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - InterUni SIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-purple: #9142ff;
            --primary-purple-hover: #7829e6;
            --light-purple: #f3e8ff;
            --text-dark: #2d213f;
        }
        body {
            background-color: #f8f9fa;
            color: var(--text-dark);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .btn-purple {
            background-color: var(--primary-purple);
            color: #ffffff;
            border: none;
            transition: all 0.2s ease;
        }
        .btn-purple:hover {
            background-color: var(--primary-purple-hover);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(145, 66, 255, 0.2);
        }
        .nav-link-purple {
            color: #6c757d;
            font-weight: 500;
            transition: color 0.2s;
        }
        .nav-link-purple:hover, .nav-link-purple.active {
            color: var(--primary-purple) !important;
        }
        .dashboard-card {
            background: #ffffff;
            border-radius: 12px;
            border: none;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .portal-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(145, 66, 255, 0.1) !important;
        }
        .icon-circle {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: var(--light-purple);
            color: var(--primary-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
    </style>
</head>
<body>

<div class="container my-5">
    <!-- Navbar Header Section -->
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 pb-3 border-bottom">
        <div class="mb-3 mb-md-0">
            <h2 class="fw-bold m-0" style="color: var(--text-dark);">InterUni SIS</h2>
            <small class="text-muted">Logged in as: <span class="badge bg-light text-dark border fw-semibold"><?php echo htmlspecialchars($_SESSION['username']); ?></span></small>
        </div>
        <nav>
            <ul class="nav gap-2">
                <li class="nav-item"><a class="nav-link nav-link-purple active" href="home.php"><i class="bi bi-house-heart-fill"></i> Home</a></li>
                <li class="nav-item"><a class="nav-link nav-link-purple" href="index.php"><i class="bi bi-person-lines-fill"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link nav-link-purple" href="about.php"><i class="bi bi-info-circle"></i> About</a></li>
                <li class="nav-item"><a class="nav-link text-danger" href="logout.php" onclick="return confirm('Log out from page?')"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-card shadow-sm p-4 p-md-5 mb-3 text-center text-md-start" style="background: linear-gradient(135deg, rgba(145, 66, 255, 0.08) 0%, rgba(243, 232, 255, 0.3) 100%);">
        <div class="row align-items-center g-4">
            <div class="col-md-10">
                <h1 class="fw-bold display-6 mb-1" style="color: var(--primary-purple); font-size: 3.2rem;">Welcome to InterUni SIS</h1>
                <p class="text-muted lead mb-0">
                    This is a central hub for academic and institutional management. This platform streamlines registration, student dashboard, and modification features for an optimized administrative workflow.
                </p>
            </div>
        </div>
    </div>
    
    <div class="mb-3 d-flex align-items-center gap-2">
      <a href="index.php" class="btn btn-purple px-4 py-2 fw-semibold">
          <i class="bi bi-speedometer2 me-1"></i> Open Student Dashboard
      </a>
      
      <a href="about.php" class="btn px-4 py-2 fw-semibold" style="background-color: var(--light-purple); color: var(--primary-purple); border: none; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
      Learn More
      </a>
</div>

    <!-- Quick Stats Metric Rows -->
    <div class="row g-4 mb-5">
        <div class="col-md-6">
            <div class="dashboard-card shadow-sm p-4 d-flex align-items-center justify-content-between">
                <div>
                    <small class="text-muted uppercase fw-semibold tracking-wider d-block mb-1">Total Active System Registrations</small>
                    <h2 class="fw-bold m-0"><?php echo $total_students; ?> Students</h2>
                </div>
                <div class="icon-circle">
                    <i class="bi bi-people-fill"></i>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="dashboard-card shadow-sm p-4 d-flex align-items-center justify-content-between">
                <div>
                    <small class="text-muted uppercase fw-semibold tracking-wider d-block mb-1">Presented Institutions</small>
                    <h2 class="fw-bold m-0"><?php echo $total_univs; ?> Universities</h2>
                </div>
                <div class="icon-circle">
                    <i class="bi bi-building-fill"></i>
                </div>
            </div>
        </div>
</div>

</div> <footer class="py-4 shadow-sm" style="background-color: #9142ff; color: #ffffff; width: 100%; margin-top: auto;">
        <div class="container text-center">
            <span class="text-white-50 ms-1 small" style="opacity: 0.6;">&copy; <?php echo date('Y'); ?> Student Information System. All rights reserved.</span>
        </div>
    </footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>