<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Global safety gatekeeper intercepting unauthenticated sessions
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header("Location: loginex.php");
    exit();
}
?>