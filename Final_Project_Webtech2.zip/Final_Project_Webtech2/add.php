<?php
include 'auth.php';
include 'config.php';

if (isset($_POST['save'])) {
    $name = mysqli_real_escape_string($conn, $_POST['txt_name']);
    $gender = mysqli_real_escape_string($conn, $_POST['txt_gender']);
    $email = mysqli_real_escape_string($conn, $_POST['txt_email']);
    $yearlvl = mysqli_real_escape_string($conn, $_POST['txt_year']);
    $course = mysqli_real_escape_string($conn, $_POST['txt_course']);
    $univ = mysqli_real_escape_string($conn, $_POST['txt_univ']);

    // Server-Side Defense Gatekeeper
    if (empty($name) || empty($email) || empty($gender) || empty($yearlvl) || empty($course) || empty($univ)) {
        header("Location: add.php?err=empty");
        exit();
    } else {
        $sql = "INSERT INTO registration (full_name, email, gender, yearlvl, course, univ) VALUES ('$name', '$email', '$gender', '$yearlvl', '$course', '$univ')";
        if (mysqli_query($conn, $sql)) { 
            header("Location: index.php?msg=added"); 
            exit(); 
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Student</title>
    <link href="css.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light container d-flex align-items-center justify-content-center min-vh-100">
    <div class="card shadow-sm border-0 col-md-8 col-lg-6">
        <div class="card-pur p-3 fw-bold text-white text-center" style="background-color: #9142ff;">Register New Student Record</div>
        <form method="POST" class="card-body p-3">
            <?php if (isset($_GET['err'])): ?>
                <div class="alert alert-danger p-2 small mb-2" role="alert">
                    Error: All processing fields must be filled completely.
                </div>
            <?php endif; ?>

            <div class="row g-2 mb-2">
                <div class="col-md-8">
                    <label class="form-label small fw-bold mb-1">Full Student Name</label>
                    <input type="text" name="txt_name" class="form-control form-control-sm" placeholder="LN, FN, MI, " required>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold mb-1 d-block">Gender</label>
                    <div class="pt-1">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="txt_gender" id="genderMale" value="Male" required>
                            <label class="form-check-label small" for="genderMale">Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="txt_gender" id="genderFemale" value="Female">
                            <label class="form-check-label small" for="genderFemale">Female</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-2 mb-2">
                <div class="col-md-7">
                    <label class="form-label small fw-bold mb-1">Email Address</label>
                    <input type="email" name="txt_email" class="form-control form-control-sm" placeholder="example@domain.com" required>
                </div>
                <div class="col-md-5">
                    <label class="form-label small fw-bold mb-1">Year Level</label>
                    <select name="txt_year" class="form-select form-select-sm" required>
                        <option value="" disabled selected>Select Year</option>
                        <option value="1st Year">1st Year</option>
                        <option value="2nd Year">2nd Year</option>
                        <option value="3rd Year">3rd Year</option>
                        <option value="4th Year">4th Year</option>
                    </select>
                </div>
            </div>

            <div class="row g-2 mb-3">
                <div class="col-md-6">
                    <label class="form-label small fw-bold mb-1">Academic Course Program</label>
                    <input type="text" name="txt_course" class="form-control form-control-sm" placeholder="e.g., BSCPE" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold mb-1">Institutional University</label>
                    <select name="txt_univ" class="form-select form-select-sm" required>
                        <option value="" disabled selected>Select University</option>
                        <option value="PUP-Sta. Mesa">PUP-Sta. Mesa</option>
                        <option value="UCP">Universal College of Parañaque (UCP)</option>
                        <option value="PHILSCA">PHILSCA</option>
                        <option value="KLD">Kolehiyo ng Lungsod ng Dasmariñas (KLD)</option>
                        <option value="PLV">Pamantasan ng Lungsod ng Valenzuela (PLV)</option>
                        <option value="BatSU">Batangas State University (BatSU)</option>
                        <option value="LTC"> Lyceum Technological Colleges (LTC)</option>
                        <option value="AISAT College - Dasmariñas">AISAT College - Dasmariñas</option>
                        <option value="LPU">LPU</option>
                        <option value="PCC">Parañaque City College (PCC)</option>
                        <option value="SJC-Dasmariñas">Saint Jude College Dasmariñas (SJC Dasmariñas)</option>
                        <option value="BPSU">Bataan Peninsula State University (BPSU)</option>
                        <option value="CVSU-Imus">CVSU-Imus</option>
                        <option value="EAC-Cavite">EAC-Cavite</option>
                        <option value="EAC-Manila">EAC-Manila</option>
                        <option value="PCCR"> Philippine College of Criminology (PCCR)</option>
                        <option value="ADMU">ADMU</option>
                        <option value="PNU">PNU</option>
                        <option value="TUP-Cavite">TUP-Cavite</option>
                        <option value="OLLTC">Our Lady of Lourdes Technological College (OLLTC)</option>
                        <option value="DLSU-Dasmariñas">DLSU-Dasmariñas</option>
                        <option value="NCST">National College of Science and Technology (NCST)</option>
                    </select>
                </div>
            </div>

            <div class="d-flex gap-2 justify-content-end">
                <a href="index.php" class="btn btn-sm btn-secondary px-3">Cancel</a>
                <button name="save" class="btn btn-sm btn-primary px-4" style="background-color: #9142ff; border: none;">Register</button>
            </div>
        </form>
    </div>
</body>
</html>