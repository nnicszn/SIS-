<?php
include 'auth.php'; // Protects this page
include 'config.php';

// 1. Get Custom Show Entries Limit (Default: 10)
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// 2. Capture and Build Name Filter
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$whereClause = !empty($search) 
    ? "WHERE full_name LIKE '%$search%' OR course LIKE '%$search%' OR univ LIKE '%$search%'" 
    : "";

// 3. Count Operations for Pagination Metrics
$total_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM registration $whereClause");
$total_data = mysqli_fetch_assoc($total_res)['total'];
$total_pages = ceil($total_data / $limit);

// 4. Fetch Targeted Partition Data Subset
$sql = "SELECT * FROM registration $whereClause LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $sql);

//modal use
$univMap = [
    "PUP-Sta. Mesa" => "Polytechnic University of the Philippines (PUP-Sta. Mesa)",
    "UCP" => "Universal College of Parañaque (UCP)",
    "PHILSCA" => "Philippine State College of Aeronautics (PHILSCA)",
    "KLD" => "Kolehiyo ng Lungsod ng Dasmariñas (KLD)",
    "PLV" => "Pamantasan ng Lungsod ng Valenzuela (PLV)",
    "BatSU" => "Batangas State University (BatSU)",
    "LTC" => "Lyceum Technological Colleges (LTC)",
    "AISAT College - Dasmariñas" => "AISAT College - Dasmariñas",
    "LPU" => "Lyceum of the Philippines University (LPU)",
    "PCC" => "Parañaque City College (PCC)",
    "SJC-Dasmariñas" => "Saint Jude College Dasmariñas (SJC Dasmariñas)",
    "BPSU" => "Bataan Peninsula State University (BPSU)",
    "CVSU-Imus" => "Cavite State University - Imus (CVSU-Imus)",
    "EAC-Cavite" => "Emilio Aguinaldo College - Cavite (EAC-Cavite)",
    "EAC-Manila" => "Emilio Aguinaldo College - Manila (EAC-Manila)",
    "PCCR" => "Philippine College of Criminology (PCCR)",
    "ADMU" => "Ateneo de Manila University (ADMU)",
    "PNU" => "Philippine Normal University (PNU)",
    "TUP-Cavite" => "Technological University of the Philippines - Cavite (TUP-Cavite)",
    "OLLTC" => "Our Lady of Lourdes Technological College (OLLTC)",
    "DLSU-Dasmariñas" => "De La Salle University - Dasmariñas (DLSU-Dasmariñas)",
    "NCST" => "National College of Science and Technology (NCST)"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InterUni SIS Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-purple: #9142ff;
            --primary-purple-hover: #7829e6;
            --light-purple: #f3e8ff;
            --text-dark: #2d213f;
        }
        body {
            background-color: #f8f9fa;
            color: var(--text-dark);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .btn-purple {
            background-color: var(--primary-purple);
            color: #ffffff;
            border: none;
            transition: all 0.2s ease;
        }
        .btn-purple:hover, .btn-purple:focus {
            background-color: var(--primary-purple-hover);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(145, 66, 255, 0.2);
        }
        .btn-outline-purple {
            color: var(--primary-purple);
            border-color: var(--primary-purple);
        }
        .btn-outline-purple:hover {
            background-color: var(--primary-purple);
            color: #fff;
        }
        .nav-link-purple {
            color: #6c757d;
            font-weight: 500;
            transition: color 0.2s;
        }
        .nav-link-purple:hover, .nav-link-purple.active {
            color: var(--primary-purple) !important;
        }
        .dashboard-card {
            background: #ffffff;
            border-radius: 12px;
            border: none;
        }
        .table-purple-header {
            background-color: var(--light-purple) !important;
            color: var(--text-dark);
        }
        .table-striped > tbody > tr:nth-of-type(odd) > * {
            --bs-table-bg-type: rgba(145, 66, 255, 0.03) !important;
        }

        .pagination .page-link {
            color: var(--primary-purple);
        }
        .pagination .page-item.active .page-link {
            background-color: var(--primary-purple) !important;
            border-color: var(--primary-purple) !important;
            color: #ffffff !important; 
        }
        
        .badge-purple {
            background-color: var(--light-purple);
            color: var(--primary-purple);
        }
        .fixed-layout-table {
            table-layout: fixed;
            width: 100%;
        }
        .table th, .table td {
            padding: 1rem 0.5rem !important;
            vertical-align: middle;
            overflow: hidden;
        }
        .clamp-2-lines {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            word-break: break-word;
        }
        .scroll-navigation-wrapper {
            position: fixed;
            bottom: 25px;
            right: 25px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            z-index: 1050;
        }
        .btn-scroll-nav {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background-color: #ffffff;
            color: var(--primary-purple);
            border: 1px solid rgba(145, 66, 255, 0.2);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            transition: all 0.2s ease-in-out;
            cursor: pointer;
        }
        .btn-scroll-nav:hover {
            background-color: var(--primary-purple);
            color: #ffffff;
            transform: translateY(-2px);
            box-shadow: 0 6px 14px rgba(145, 66, 255, 0.3);
        }
    </style>
</head>
<body>

<div class="container my-5">
    <header class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 pb-3 border-bottom">
        <div class="mb-3 mb-md-0">
            <h2 class="fw-bold m-0" style="color: var(--text-dark);">InterUni SIS Dashboard</h2>
            <small class="text-muted">Logged in as: <span class="badge bg-light text-dark border fw-semibold"><?php echo htmlspecialchars($_SESSION['username']); ?></span></small>
        </div>
        <nav>
            <ul class="nav gap-2">
                <li class="nav-item"><a class="nav-link nav-link-purple" href="home.php"><i class="bi bi-house-heart-fill"></i> Home</a></li>
                <li class="nav-item"><a class="nav-link nav-link-purple active" href="index.php"><i class="bi bi-person-lines-fill"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link nav-link-purple" href="about.php"><i class="bi bi-info-circle"></i> About</a></li>
                <li class="nav-item"><a class="nav-link text-danger" href="logout.php" onclick="return confirm('Log out from page?')"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
            </ul>
        </nav>
    </header>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-dismissible fade show shadow-sm border-0 bg-white" role="alert" style="border-left: 4px solid <?php echo ($_GET['msg']=='deleted') ? '#ff4242' : '#9142ff'; ?> !important;">
            <?php if($_GET['msg'] == 'added'): ?>
                <strong>Success!</strong> New student has been registered.
            <?php elseif($_GET['msg'] == 'updated'): ?>
                <strong>Updated!</strong> Student details have been modified.
            <?php elseif($_GET['msg'] == 'deleted'): ?>
                <strong>Removed!</strong> Student record has been deleted.
            <?php endif; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="dashboard-card shadow-sm p-4 mb-4">
        <div class="row g-3 align-items-center">
            <div class="col-lg-5 col-md-6">
                <form method="GET" action="index.php" class="d-flex gap-2">
                    <input type="hidden" name="limit" value="<?php echo $limit; ?>">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control border-start-0 ps-0" placeholder="Search name, course, or university" value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <button type="submit" class="btn btn-purple px-4">Search</button>
                </form>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <form method="GET" action="index.php" id="entriesForm" class="d-flex align-items-center gap-2">
                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                    <span class="text-muted small">Show</span>
                    <select name="limit" class="form-select form-select-sm" style="width: auto; min-width: 70px;" onchange="document.getElementById('entriesForm').submit();">
                        <option value="5" <?php echo ($limit == 5) ? 'selected' : ''; ?>>5</option>
                        <option value="10" <?php echo ($limit == 10) ? 'selected' : ''; ?>>10</option>
                        <option value="25" <?php echo ($limit == 25) ? 'selected' : ''; ?>>25</option>
                    </select>
                    <span class="text-muted small">entries</span>
                </form>
            </div>

            <div class="col-lg-4 col-12 text-md-end d-flex gap-2 justify-content-lg-end">
                <a href="add.php" class="btn btn-purple btn-sm px-3 d-flex align-items-center gap-1 ms-auto ms-lg-0">
                    <i class="bi bi-person-plus-fill"></i> Register Student
                </a>
            </div>
        </div>
    </div>

    <div class="dashboard-card shadow-sm overflow-hidden mb-4">
        <form method="POST">
            <div>
                <table class="table table-striped table-hover align-middle mb-0 fixed-layout-table">
                    <thead class="table-purple-header">
                        <tr>
                            <th style="width: 4%;">ID</th> 
                            <th style="width: 20%;">Full Name</th>
                            <th style="width: 9%;">Gender</th>
                            <th style="width: 20%;">Email Address</th>
                            <th style="width: 10%;" class="text-center">Year</th>
                            <th style="width: 10%;">Course</th>
                            <th style="width: 10%;">University</th>
                            <th style="width: 12%;" class="text-center pe-3">Actions</th> 
                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): 
                                $savedUniv = trim($row['univ']); 
                                $fullUniversityName = isset($univMap[$savedUniv]) ? $univMap[$savedUniv] : $savedUniv;
                            ?>
                            <tr>
                                <td class="text-muted fw-semibold"><?php echo $row['id']; ?></td>
                                <td class="fw-bold"><div class="clamp-2-lines"><?php echo htmlspecialchars($row['full_name']); ?></div></td>
                                <td><?php echo htmlspecialchars($row['gender']); ?></td>
                                <td class="text-muted"><div class="clamp-2-lines"><?php echo htmlspecialchars($row['email']); ?></div></td>
                                <td class="text-center"><span class="text-dark"><?php echo htmlspecialchars($row['yearlvl']); ?></span></td>
                                <td><div class="clamp-2-lines"><span class="badge badge-purple px-2 py-1"><?php echo htmlspecialchars($row['course']); ?></span></div></td>
                                <td><div class="clamp-2-lines text-muted"><?php echo htmlspecialchars($row['univ']); ?></div></td>
                                <td class="text-center pe-3 text-nowrap"> 
                                    <div class="btn-group gap-1">
                                        <button type="button" class="btn btn-sm btn-light border" data-bs-toggle="modal" data-bs-target="#studentModal<?php echo $row['id']; ?>" title="View Details">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <a href="edit.php?id=<?php echo $row['id']; ?>&page=<?php echo $page; ?>" class="btn btn-sm btn-outline-purple" title="Edit Record">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="delete.php?id=<?php echo $row['id']; ?>&page=<?php echo $page; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Permanently remove this record?')" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                                <!-- Modal for Student Details -->
                            <div class="modal fade" id="studentModal<?php echo $row['id']; ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
                                        <div class="modal-header text-white px-4 py-2" style="background-color: var(--primary-purple);">
                                            <h5 class="modal-title d-flex align-items-center gap-2"><i class="bi bi-person-badge"></i> Student Profile</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body p-3">
                                            <div class="text-center mb-4">
                                                <h4 class="fw-bold mb-1"><?php echo htmlspecialchars($row['full_name']); ?></h4>
                                                <span class="badge badge-purple"><?php echo htmlspecialchars($row['course']); ?></span>
                                            </div>
                                            
                                            <div class="row g-3 bg-light p-3 rounded-3">
                                                <div class="col-6">
                                                    <small class="text-muted d-block uppercase tracking-wider">Student ID</small>
                                                    <span class="fw-semibold"><?php echo htmlspecialchars($row['id']); ?></span>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted d-block">Gender</small>
                                                    <span class="fw-semibold"><?php echo htmlspecialchars($row['gender']); ?></span>
                                                </div>
                                                <div class="col-6 border-top pt-2">
                                                    <small class="text-muted d-block">Year Level</small>
                                                    <span class="fw-semibold"><?php echo htmlspecialchars($row['yearlvl']); ?></span>
                                                </div>
                                                <div class="col-6 border-top pt-2">
                                                    <small class="text-muted d-block">University</small>
                                                    <span class="fw-semibold text-break"><?php echo htmlspecialchars($fullUniversityName); ?></span>
                                                </div>
                                                <div class="col-12 border-top pt-2">
                                                    <small class="text-muted d-block">Email Address</small>
                                                    <span class="fw-semibold text-break"><?php echo htmlspecialchars($row['email']); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-5">
                                    <i class="bi bi-folder-x display-6 d-block mb-2 text-secondary"></i>
                                    No matching registration data records found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="bg-light p-3 border-top px-4">
                <span class="text-muted small">
                    Showing exactly <strong><?php echo mysqli_num_rows($result); ?></strong> record(s) on this viewport page. (Grand Dataset Total: <strong><?php echo $total_data; ?></strong> rows)
                </span>
            </div>
        </form>
    </div>

    <?php if ($total_pages > 1): ?>
    <nav aria-label="Page navigation" class="mt-4">
        <ul class="pagination justify-content-center">
            <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                <a class="page-link shadow-sm border-0 mx-1 rounded" href="?page=<?php echo $page - 1; ?>&search=<?php echo $search; ?>&limit=<?php echo $limit; ?>">&laquo;</a>
            </li>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php if ($page == $i) echo 'active'; ?>">
                    <a class="page-link shadow-sm border-0 mx-1 rounded" href="?page=<?php echo $i; ?>&search=<?php echo $search; ?>&limit=<?php echo $limit; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php if ($page >= $total_pages) echo 'disabled'; ?>">
                <a class="page-link shadow-sm border-0 mx-1 rounded" href="?page=<?php echo $page + 1; ?>&search=<?php echo $search; ?>&limit=<?php echo $limit; ?>">&raquo;</a>
            </li>
        </ul>
    </nav>
    <?php endif; ?>
</div>

<div class="scroll-navigation-wrapper">
    <button class="btn-scroll-nav" onclick="scrollToTop()" title="Scroll to Top">
        <i class="bi bi-arrow-up"></i>
    </button>
    <button class="btn-scroll-nav" onclick="scrollToBottom()" title="Scroll to Bottom">
        <i class="bi bi-arrow-down"></i>
    </button>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>

function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

function scrollToBottom() {
    window.scrollTo({
        top: document.documentElement.scrollHeight,
        behavior: 'smooth'
    });
}
</script>
</body>
</html>