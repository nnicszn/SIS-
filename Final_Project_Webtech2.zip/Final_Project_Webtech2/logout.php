<?php
session_start();

// Flush all memory session assignments
$_SESSION = array();

// Wipe validation tracking tokens from server environment completely
session_destroy();

header("Location: loginex.php");
exit();
?>