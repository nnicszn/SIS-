<?php
include 'auth.php'; // Protects this page from unauthorized access
include 'config.php';

// --- LAYER 1: FETCH EXISTING DATA ---
if (isset($_GET['id'])) {
    $id = (int)$_GET['id']; // Cast to integer for security
    $page = (int)$_GET['page']; // Retrieve Page Number

    // Query to fetch the specific student's details
    $sql = "SELECT * FROM registration WHERE id = $id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $student = mysqli_fetch_assoc($result);
    } else {
        // Redirect back if the student ID doesn't exist
        header("Location: index.php");
        exit();
    }
} else if (isset($_POST['btn_update'])) {
    // --- LAYER 2: PROCESS THE UPDATE LOGIC ---
    $id = $_POST['txt_id'];
    $page = $_POST['page'];
    $name = mysqli_real_escape_string($conn, $_POST['txt_name']);
    $email = mysqli_real_escape_string($conn, $_POST['txt_email']);
    $gender = mysqli_real_escape_string($conn, $_POST['txt_gender']);
    $yearlvl = mysqli_real_escape_string($conn, $_POST['txt_year']);
    $course = mysqli_real_escape_string($conn, $_POST['txt_course']);
    $univ = mysqli_real_escape_string($conn, $_POST['txt_univ']);

    // Defensive Server-Side Validation
    if (empty($name) || empty($email) || empty($gender) || empty($yearlvl) || empty($course) || empty($univ)) {
        header("Location: edit.php?id=$id&err=empty");
        exit();
    } else {
        // Construct the UPDATE statement targeting the unique record ID
        $sql = "UPDATE registration SET full_name = '$name', email = '$email', gender = '$gender', yearlvl = '$yearlvl', course = '$course', univ = '$univ' WHERE id = $id";
        
        if (mysqli_query($conn, $sql)) {
            header("Location: index.php?id=$id&page=$page&msg=updated");
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
} else {
    // Redirect if accessed directly without a GET or POST payload
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student Record</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light container d-flex align-items-center justify-content-center min-vh-100">
    <div class="card shadow-sm border-0 col-md-8 col-lg-6">
        <div class="card-header bg-info text-white fw-bold text-center p-3">Modify Student Registration Record</div>
        <form method="POST" action="edit.php" class="card-body p-3">
            
            <?php if (isset($_GET['err'])): ?>
                <div class="alert alert-danger p-2 small mb-2">Error: All processing fields must be filled completely.</div>
            <?php endif; ?>

            <input type="hidden" name="txt_id" value="<?php echo $student['id']; ?>">
            <input type="hidden" name="page" value="<?php echo $page; ?>">

            <div class="row g-2 mb-2">
                <div class="col-md-8">
                    <label class="form-label small fw-bold mb-1">Full Student Name</label>
                    <input type="text" name="txt_name" class="form-control form-control-sm" value="<?php echo htmlspecialchars($student['full_name']); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold mb-1 d-block">Gender</label>
                    <div class="pt-1">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="txt_gender" id="editMale" value="Male" <?php echo ($student['gender'] === 'Male') ? 'checked' : ''; ?> required>
                            <label class="form-check-label small" for="editMale">Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="txt_gender" id="editFemale" value="Female" <?php echo ($student['gender'] === 'Female') ? 'checked' : ''; ?>>
                            <label class="form-check-label small" for="editFemale">Female</label>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row g-2 mb-2">
                <div class="col-md-7">
                    <label class="form-label small fw-bold mb-1">Email Address</label>
                    <input type="email" name="txt_email" class="form-control form-control-sm" value="<?php echo htmlspecialchars($student['email']); ?>" required>
                </div>
                <div class="col-md-5">
                    <label class="form-label small fw-bold mb-1">Year Level</label>
                    <select name="txt_year" class="form-select form-select-sm" required>
                        <option value="1st Year" <?php echo ($student['yearlvl'] === '1st Year') ? 'selected' : ''; ?>>1st Year</option>
                        <option value="2nd Year" <?php echo ($student['yearlvl'] === '2nd Year') ? 'selected' : ''; ?>>2nd Year</option>
                        <option value="3rd Year" <?php echo ($student['yearlvl'] === '3rd Year') ? 'selected' : ''; ?>>3rd Year</option>
                        <option value="4th Year" <?php echo ($student['yearlvl'] === '4th Year') ? 'selected' : ''; ?>>4th Year</option>
                    </select>
                </div>
            </div>

            <div class="row g-2 mb-3">
                <div class="col-md-6">
                    <label class="form-label small fw-bold mb-1">Academic Course Program</label>
                    <input type="text" name="txt_course" class="form-control form-control-sm" value="<?php echo htmlspecialchars($student['course']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold mb-1">University</label>
                    <select name="txt_univ" class="form-select form-select-sm" required>
                        <option value="PUP-Sta. Mesa" <?php echo ($student['univ'] === 'PUP-Sta. Mesa') ? 'selected' : ''; ?>>PUP-Sta. Mesa</option>
                        <option value="UCP" <?php echo ($student['univ'] === 'UCP') ? 'selected' : ''; ?>>Universal College of Parañaque (UCP)</option>
                        <option value="PHILSCA" <?php echo ($student['univ'] === 'PHILSCA') ? 'selected' : ''; ?>>PHILSCA</option>
                        <option value="KLD" <?php echo ($student['univ'] === 'KLD') ? 'selected' : ''; ?>>Kolehiyo ng Lungsod ng Dasmariñas (KLD)</option>
                        <option value="PLV" <?php echo ($student['univ'] === 'PLV') ? 'selected' : ''; ?>>Pamantasan ng Lungsod ng Valenzuela (PLV)</option>
                        <option value="BatSU" <?php echo ($student['univ'] === 'BatSU') ? 'selected' : ''; ?>>Batangas State University (BatSU)</option>
                        <option value="LTC" <?php echo ($student['univ'] === 'LTC') ? 'selected' : ''; ?>> Lyceum Technological Colleges (LTC)</option>
                        <option value="AISAT College - Dasmariñas" <?php echo ($student['univ'] === 'AISAT College - Dasmariñas') ? 'selected' : ''; ?>>AISAT College - Dasmariñas (AISAT)</option>
                        <option value="LPU" <?php echo ($student['univ'] === 'LPU') ? 'selected' : ''; ?>>LPU</option>
                        <option value="PCC" <?php echo ($student['univ'] === 'PCC') ? 'selected' : ''; ?>>Parañaque City College (PCC)</option>
                        <option value="SJC-Dasmariñas" <?php echo ($student['univ'] === 'SJC-Dasmariñas') ? 'selected' : ''; ?>>Saint Jude College Dasmariñas (SJC Dasmariñas)</option>
                        <option value="BPSU" <?php echo ($student['univ'] === 'BPSU') ? 'selected' : ''; ?>>Bataan Peninsula State University (BPSU)</option>
                        <option value="CVSU-Imus" <?php echo ($student['univ'] === 'CVSU-Imus') ? 'selected' : ''; ?>>CVSU-Imus (CVSU-Imus)</option>
                        <option value="EAC-Cavite" <?php echo ($student['univ'] === 'EAC-Cavite') ? 'selected' : ''; ?>>EAC-Cavite (EAC-Cavite)</option>
                        <option value="EAC-Manila" <?php echo ($student['univ'] === 'EAC-Manila') ? 'selected' : ''; ?>>EAC-Manila (EAC-Manila)</option>
                        <option value="PCCR" <?php echo ($student['univ'] === 'PCCR') ? 'selected' : ''; ?>> Philippine College of Criminology (PCCR)</option>
                        <option value="ADMU" <?php echo ($student['univ'] === 'ADMU') ? 'selected' : ''; ?>>ADMU</option>
                        <option value="PNU" <?php echo ($student['univ'] === 'PNU') ? 'selected' : ''; ?>>PNU</option>
                        <option value="TUP-Cavite" <?php echo ($student['univ'] === 'TUP-Cavite') ? 'selected' : ''; ?>>TUP-Cavite</option>
                        <option value="OLLTC" <?php echo ($student['univ'] === 'OLLTC') ? 'selected' : ''; ?>>Our Lady of Lourdes Technological College (OLLTC)</option>
                        <option value="DLSU-Dasmariñas" <?php echo ($student['univ'] === 'DLSU-Dasmariñas') ? 'selected' : ''; ?>>DLSU-Dasmariñas (DLSU-Dasmariñas)</option>
                        <option value="NCST" <?php echo ($student['univ'] === 'NCST') ? 'selected' : ''; ?>>National College of Science and Technology (NCST)</option>
                    </select>
                </div>
            </div>
            
            <div class="d-flex gap-2 justify-content-end">
                <a href="index.php" class="btn btn-sm btn-secondary px-3">Cancel</a>
                <button name="btn_update" class="btn btn-sm btn-info text-white px-4">Update Details</button>
            </div>
        </form>
    </div>
</body>
</html>